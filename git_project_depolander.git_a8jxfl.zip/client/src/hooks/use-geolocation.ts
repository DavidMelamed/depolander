import { useState, useEffect } from 'react';

interface GeolocationState {
  city?: string;
  state?: string;
  loading: boolean;
  error?: string;
}

export function useGeolocation() {
  const [location, setLocation] = useState<GeolocationState>({
    loading: true
  });

  useEffect(() => {
    async function getLocation() {
      try {
        const response = await fetch('https://ipapi.co/json/');
        const data = await response.json();
        
        setLocation({
          city: data.city,
          state: data.region_code,
          loading: false
        });
      } catch (error) {
        setLocation({
          loading: false,
          error: 'Failed to detect location'
        });
      }
    }

    getLocation();
  }, []);

  return location;
}
