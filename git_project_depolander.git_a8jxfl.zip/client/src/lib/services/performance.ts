export class PerformanceMonitor {
  private metrics: {
    fcp: number;
    lcp: number;
    cls: number;
    fid: number;
  } = {
    fcp: 0,
    lcp: 0,
    cls: 0,
    fid: 0
  };

  initialize() {
    // First Contentful Paint
    new PerformanceObserver((entryList) => {
      const entries = entryList.getEntries();
      this.metrics.fcp = entries[entries.length - 1].startTime;
    }).observe({ entryTypes: ['paint'] });

    // Largest Contentful Paint
    new PerformanceObserver((entryList) => {
      const entries = entryList.getEntries();
      this.metrics.lcp = entries[entries.length - 1].startTime;
    }).observe({ entryTypes: ['largest-contentful-paint'] });

    // Cumulative Layout Shift
    new PerformanceObserver((entryList) => {
      let cls = 0;
      for (const entry of entryList.getEntries()) {
        if (!entry.hadRecentInput) {
          cls += (entry as any).value;
        }
      }
      this.metrics.cls = cls;
    }).observe({ entryTypes: ['layout-shift'] });

    // First Input Delay
    new PerformanceObserver((entryList) => {
      const entries = entryList.getEntries();
      this.metrics.fid = entries[0].duration;
    }).observe({ entryTypes: ['first-input'] });
  }

  getMetrics() {
    return this.metrics;
  }

  isPerformant(): boolean {
    return (
      this.metrics.fcp < 2000 &&
      this.metrics.lcp < 2500 &&
      this.metrics.cls < 0.1 &&
      this.metrics.fid < 100
    );
  }
}

export const performanceMonitor = new PerformanceMonitor();
