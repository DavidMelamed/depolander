import { siteConfig } from "@/lib/config";

interface ConversionEvent {
  type: 'call' | 'form' | 'chat';
  source: string;
  location: {
    state: string;
    city?: string;
  };
  timestamp: number;
}

export class ConversionTracker {
  private static instance: ConversionTracker;
  private events: ConversionEvent[] = [];

  static getInstance() {
    if (!this.instance) {
      this.instance = new ConversionTracker();
    }
    return this.instance;
  }

  trackEvent(event: Omit<ConversionEvent, 'timestamp'>) {
    const fullEvent = {
      ...event,
      timestamp: Date.now()
    };

    // Send to multiple analytics systems
    this.sendToGTM(fullEvent);
    this.sendToRingba(fullEvent);
    
    // Store locally for analysis
    this.events.push(fullEvent);
  }

  private sendToGTM(event: ConversionEvent) {
    if (window.dataLayer && siteConfig.tracking.gtmId) {
      window.dataLayer.push({
        event: 'tort_conversion',
        eventType: event.type,
        eventSource: event.source,
        userState: event.location.state,
        userCity: event.location.city
      });
    }
  }

  private sendToRingba(event: ConversionEvent) {
    if (window.Ringba && siteConfig.tracking.ringbaId) {
      // Implement Ringba-specific tracking
    }
  }

  getConversionRate(): number {
    const visitors = this.getVisitorCount();
    const conversions = this.events.length;
    return visitors > 0 ? (conversions / visitors) * 100 : 0;
  }

  private getVisitorCount(): number {
    // Implement real visitor counting
    return 100;
  }
}

export const conversionTracker = ConversionTracker.getInstance();
