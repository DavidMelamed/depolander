```typescript
import { ChatOpenAI } from 'langchain/chat_models/openai';
import { ConversationChain } from 'langchain/chains';
import { BufferMemory } from 'langchain/memory';
import { PromptTemplate } from 'langchain/prompts';

interface ChatContext {
  tort: string;
  userLocation: string;
  caseDetails?: Record<string, any>;
  previousInteractions?: Array<{
    type: string;
    timestamp: number;
    data: any;
  }>;
}

export class TortChatSystem {
  private model: ChatOpenAI;
  private chain: ConversationChain;
  private memory: BufferMemory;
  private context: ChatContext;

  constructor(context: ChatContext) {
    this.context = context;
    this.initializeChat();
  }

  private async initializeChat() {
    this.model = new ChatOpenAI({
      modelName: 'gpt-4',
      temperature: 0.7
    });

    this.memory = new BufferMemory({
      returnMessages: true,
      memoryKey: 'chat_history'
    });

    const template = `
      You are a knowledgeable and empathetic legal assistant specializing in ${this.context.tort} cases.
      Location: ${this.context.userLocation}
      
      Current conversation:
      {chat_history}
      
      Human: {input}
      Assistant: Let me help you understand your legal options regarding ${this.context.tort}.
    `;

    const prompt = PromptTemplate.fromTemplate(template);

    this.chain = new ConversationChain({
      llm: this.model,
      memory: this.memory,
      prompt
    });
  }

  async processMessage(message: string) {
    // Check for qualifying questions
    const qualifyingInfo = await this.extractQualifyingInfo(message);
    if (qualifyingInfo) {
      this.updateContext(qualifyingInfo);
    }

    // Generate response
    const response = await this.chain.call({
      input: message
    });

    // Track interaction
    this.trackInteraction('chat', {
      message,
      response: response.response,
      qualifyingInfo
    });

    return {
      response: response.response,
      nextSteps: await this.generateNextSteps(),
      cta: this.generateCTA()
    };
  }

  private async extractQualifyingInfo(message: string) {
    const analysis = await this.model.call([{
      role: 'system',
      content: `Extract qualifying information for ${this.context.tort} case:
        - Usage dates
        - Symptoms/conditions
        - Medical procedures
        - Current status
        Return as JSON or null if no qualifying info found.`
    }, {
      role: 'user',
      content: message
    }]);

    try {
      return JSON.parse(analysis.content);
    } catch {
      return null;
    }
  }

  private async generateNextSteps() {
    const qualifying = this.context.caseDetails?.qualifying;
    if (!qualifying) return null;

    return {
      type: qualifying ? 'qualified' : 'information',
      steps: qualifying ? [
        'Complete quick eligibility form',
        'Speak with legal specialist',
        'Review case details',
        'Discuss compensation options'
      ] : [
        'Learn more about qualification criteria',
        'Review frequently asked questions',
        'Schedule free consultation'
      ]
    };
  }

  private generateCTA() {
    const qualifying = this.context.caseDetails?.qualifying;
    return {
      type: qualifying ? 'primary' : 'secondary',
      text: qualifying ? 'Start Your Claim Now' : 'Check Your Eligibility',
      action: qualifying ? 'initiate_claim' : 'check_eligibility'
    };
  }

  private trackInteraction(type: string, data: any) {
    this.context.previousInteractions = [
      ...(this.context.previousInteractions || []),
      {
        type,
        timestamp: Date.now(),
        data
      }
    ];
  }
}
```
