```typescript
import { PerformanceMetrics } from './types/performance';
import { WebVitals } from './web-vitals';

interface PerformanceAlert {
  type: 'critical' | 'warning' | 'info';
  metric: string;
  value: number;
  threshold: number;
  timestamp: number;
  url: string;
  context: Record<string, any>;
}

export class RealTimePerformanceMonitor {
  private webVitals: WebVitals;
  private alerts: PerformanceAlert[] = [];
  private thresholds = {
    LCP: 2500, // Largest Contentful Paint
    FID: 100,  // First Input Delay
    CLS: 0.1,  // Cumulative Layout Shift
    TTI: 3500, // Time to Interactive
    FCP: 1800  // First Contentful Paint
  };

  constructor() {
    this.initializeMonitoring();
  }

  private initializeMonitoring() {
    // Monitor Core Web Vitals
    this.webVitals.onLCP(this.handleLCP.bind(this));
    this.webVitals.onFID(this.handleFID.bind(this));
    this.webVitals.onCLS(this.handleCLS.bind(this));
    this.webVitals.onTTFB(this.handleTTFB.bind(this));
    this.webVitals.onFCP(this.handleFCP.bind(this));

    // Monitor Resource Loading
    this.observeResourceTiming();
    
    // Monitor JavaScript Errors
    this.observeErrors();
    
    // Monitor Network Requests
    this.observeNetwork();
    
    // Monitor Memory Usage
    this.observeMemory();
  }

  private handleMetric(name: string, value: number) {
    const threshold = this.thresholds[name];
    if (value > threshold) {
      this.createAlert({
        type: value > threshold * 1.5 ? 'critical' : 'warning',
        metric: name,
        value,
        threshold,
        timestamp: Date.now(),
        url: window.location.href,
        context: this.gatherContext()
      });
    }
  }

  private observeResourceTiming() {
    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (entry.duration > 1000) { // 1 second threshold
          this.createAlert({
            type: 'warning',
            metric: 'ResourceTiming',
            value: entry.duration,
            threshold: 1000,
            timestamp: Date.now(),
            url: entry.name,
            context: {
              initiatorType: entry.initiatorType,
              size: entry.transferSize,
              type: entry.entryType
            }
          });
        }
      }
    });

    observer.observe({ entryTypes: ['resource'] });
  }

  private observeNetwork() {
    const originalFetch = window.fetch;
    window.fetch = async (...args) => {
      const start = performance.now();
      try {
        const response = await originalFetch(...args);
        this.trackNetworkRequest(args[0].toString(), 'fetch', performance.now() - start, response.status);
        return response;
      } catch (error) {
        this.trackNetworkError(args[0].toString(), 'fetch', error);
        throw error;
      }
    };

    // Also monitor XMLHttpRequest
    const originalXHR = window.XMLHttpRequest.prototype.open;
    window.XMLHttpRequest.prototype.open = function(...args) {
      const start = performance.now();
      this.addEventListener('load', () => {
        this.trackNetworkRequest(args[1], 'xhr', performance.now() - start, this.status);
      });
      this.addEventListener('error', (error) => {
        this.trackNetworkError(args[1], 'xhr', error);
      });
      return originalXHR.apply(this, args);
    };
  }

  private trackNetworkRequest(url: string, type: string, duration: number, status: number) {
    if (duration > 3000 || status >= 400) {
      this.createAlert({
        type: status >= 500 ? 'critical' : 'warning',
        metric: 'NetworkRequest',
        value: duration,
        threshold: 3000,
        timestamp: Date.now(),
        url,
        context: {
          type,
          status,
          headers: this.sanitizeHeaders(headers)
        }
      });
    }
  }

  private gatherContext(): Record<string, any> {
    return {
      userAgent: navigator.userAgent,
      viewport: {
        width: window.innerWidth,
        height: window.innerHeight
      },
      connection: navigator.connection ? {
        effectiveType: navigator.connection.effectiveType,
        downlink: navigator.connection.downlink,
        rtt: navigator.connection.rtt
      } : null,
      memory: (performance as any).memory ? {
        usedJSHeapSize: (performance as any).memory.usedJSHeapSize,
        totalJSHeapSize: (performance as any).memory.totalJSHeapSize
      } : null,
      timestamp: new Date().toISOString()
    };
  }

  public getPerformanceReport(): PerformanceMetrics {
    return {
      webVitals: this.webVitals.getMetrics(),
      resources: this.getResourceMetrics(),
      network: this.getNetworkMetrics(),
      memory: this.getMemoryMetrics(),
      alerts: this.getRecentAlerts()
    };
  }
}
```
