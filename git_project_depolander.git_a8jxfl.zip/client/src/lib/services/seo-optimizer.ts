interface SEOMetadata {
  title: string;
  description: string;
  keywords: string[];
  canonicalUrl?: string;
  structuredData?: object;
}

export class SEOOptimizer {
  generateMetadata(state: string, content: any): SEOMetadata {
    const title = `${state} Depo-Provera Lawsuit | Check Your Eligibility`;
    const description = this.generateDescription(state, content);
    const keywords = this.generateKeywords(state);

    return {
      title,
      description,
      keywords,
      canonicalUrl: `https://depolawsuit.com/states/${state.toLowerCase()}`,
      structuredData: this.generateStructuredData(state, content)
    };
  }

  private generateDescription(state: string, content: any): string {
    return `Local legal help for ${state} residents affected by Depo-Provera. Learn about potential compensation and your legal rights. Free case evaluation available.`;
  }

  private generateKeywords(state: string): string[] {
    return [
      `${state} Depo-Provera lawsuit`,
      `${state} brain tumor lawsuit`,
      'legal help near me',
      'Depo-Provera compensation',
      'local legal assistance',
      `${state} mass tort lawyer`
    ];
  }

  private generateStructuredData(state: string, content: any) {
    return {
      "@context": "https://schema.org",
      "@type": "LegalService",
      "name": `${state} Depo-Provera Legal Help`,
      "description": content.heroDescription,
      "areaServed": {
        "@type": "State",
        "name": state
      },
      "serviceType": "Legal Consultation",
      "provider": {
        "@type": "Organization",
        "name": "Depo-Provera Legal Network"
      }
    };
  }
}

export const seoOptimizer = new SEOOptimizer();
