import { generateLocalizedContent } from "./smart-localize";

export async function generateBatch(states: string[]) {
  const results = [];
  
  for (const state of states) {
    try {
      let content = await generateLocalizedContent(state);
      
      // Retry up to 3 times if quality checks fail
      let attempts = 1;
      while (!content.passed && attempts < 3) {
        attempts++;
        const retryContent = await generateLocalizedContent(state);
        if (retryContent.passed) {
          content = retryContent;
          break;
        }
      }

      results.push({
        state,
        content,
        passed: content.passed,
        attempts
      });
    } catch (error) {
      results.push({
        state,
        error: error.message,
        passed: false
      });
    }
  }
  
  return results;
}

export async function validateStateContent(content: any) {
  const issues = [];
  
  // Check for required sections
  const requiredSections = ['hero', 'benefits', 'cities', 'disclaimer'];
  for (const section of requiredSections) {
    if (!content[section]) {
      issues.push(`Missing required section: ${section}`);
    }
  }

  // Check content length
  if (content.hero?.title?.length > 60) {
    issues.push('Hero title exceeds 60 characters');
  }

  // Check for required elements
  if (!content.cities?.length || content.cities.length < 3) {
    issues.push('Needs at least 3 major cities');
  }

  return {
    valid: issues.length === 0,
    issues
  };
}
