import { siteConfig } from "@/lib/config";

const QUALITY_CHECKS = [
  {
    name: "no-guarantees",
    test: (content) => !/(guarantee|promise|win)/gi.test(content)
  },
  {
    name: "local-reference",
    test: (content) => 
      (content.match(/serving\s+[A-Z]{2}/gi) || []).length >= 2 &&
      (content.match(/local\s+(law|resources)/gi) || []).length >= 1
  },
  {
    name: "eligibility-mention",
    test: (content) => 
      (content.match(/eligibility|qualify|check/gi) || []).length >= 3
  }
];

const BASE_PROMPT = (state: string) => `
Generate conversion-focused legal content for ${state} residents:

1. Local Relevance:
- Mention 3-5 major cities in ${state}
- Reference ${state} consumer protection laws
- Use phrases like "serving ${state} families" and "local legal resources"

2. Conversion Drivers:
- 3 variations of "Check Your Eligibility" 
- Emphasize "no upfront costs" and "local case evaluation"
- Include phrases like "compensation may be available" not guarantees

3. SEO Optimization:
- Primary keyword: "${state} Depo-Provera lawsuit"
- Secondary keywords: "${state} brain tumor compensation", "local Depo lawyer"
- Location modifiers: "near me", "in [City]"

4. Empathetic Tone:
- Focus on medical journey and seeking answers
- Use phrases like "we understand local challenges"
- Maintain hopeful but realistic tone

Structure response in JSON format with: 
- heroTitle
- heroDescription (60-80 chars with location keywords)
- benefits (array with local statistics)
- eligibilitySection
- metaDescription
`;

export async function generateLocalizedContent(state: string) {
  const response = await fetch("/api/ai/generate", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-AI-Provider": siteConfig.ai.contentProvider
    },
    body: JSON.stringify({ 
      prompt: BASE_PROMPT(state),
      state 
    })
  });

  const content = await response.json();
  const qualityResults = QUALITY_CHECKS.map(check => ({
    name: check.name,
    passed: check.test(JSON.stringify(content))
  }));

  return {
    content,
    quality: qualityResults,
    passed: qualityResults.every(r => r.passed)
  };
}
