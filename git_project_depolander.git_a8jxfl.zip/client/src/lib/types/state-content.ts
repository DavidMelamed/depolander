export interface StateContent {
  heroTitle: string;
  heroDescription: string;
  benefits: Array<{
    title: string;
    description: string;
    icon?: string;
  }>;
  cities: string[];
  disclaimer: string;
  imagePrompt?: string;
  metaDescription: string;
}

export interface QualityCheck {
  name: string;
  passed: boolean;
  details?: string;
}

export interface StateContentResult {
  content: StateContent;
  quality: QualityCheck[];
  passed: boolean;
  meta?: {
    generatedAt: string;
    aiModel: string;
  };
}

export interface BatchGenerationResult {
  state: string;
  content?: StateContentResult;
  error?: string;
  passed: boolean;
  attempts?: number;
}
