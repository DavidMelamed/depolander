import { Button } from "@/components/ui/button";
import { siteConfig } from "@/lib/config";
import { useGeolocation } from "@/hooks/use-geolocation";

interface LocalCTAProps {
  state: string;
  cities: string[];
}

export default function LocalCTA({ state, cities }: LocalCTAProps) {
  const { city } = useGeolocation();
  const displayCity = city || cities[0];
  
  return (
    <div className="local-cta bg-primary/10 p-6 rounded-xl">
      <h3 className="text-xl font-semibold">
        {displayCity} Residents: Check Your Eligibility
      </h3>
      
      <p className="my-4 text-lg">
        Find Out Within 2 Minutes If You May Qualify For Compensation
      </p>
      
      <div className="flex flex-col sm:flex-row gap-4">
        <Button 
          size="lg"
          className="bg-primary hover:bg-primary/90 text-white"
          onClick={() => window.location.href = `tel:${siteConfig.contact.phone}`}
        >
          Call {siteConfig.contact.phone}
        </Button>
        
        <Button 
          variant="outline"
          size="lg"
          onClick={() => document.getElementById('lead-form')?.scrollIntoView({ behavior: 'smooth' })}
        >
          Start Free Evaluation
        </Button>
      </div>
      
      <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-2">
        {cities.slice(0, 3).map(city => (
          <div key={city} className="text-sm text-muted-foreground">
            • Serving {city} Area
          </div>
        ))}
      </div>
      
      <p className="text-xs mt-4 text-muted-foreground">
        Serving {state} residents since {new Date().getFullYear() - 2}
        <br />
        No fees unless we win your case
      </p>
    </div>
  );
}
