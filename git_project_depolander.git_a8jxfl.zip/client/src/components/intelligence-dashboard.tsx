```typescript
import { useState, useEffect } from 'react';
import { MarketIntelligence } from '@/lib/services/market-intelligence';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';

export function IntelligenceDashboard() {
  const [activeVariation, setActiveVariation] = useState<string>(null);
  const [variations, setVariations] = useState<PageVariation[]>([]);
  const [marketData, setMarketData] = useState<MarketData>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const generateVariations = async () => {
    setIsGenerating(true);
    try {
      const intelligence = new MarketIntelligence();
      
      // Analyze competitors
      const insights = await intelligence.analyzeCompetitors([
        'competitor1.com',
        'competitor2.com'
      ]);

      // Generate variations
      const newVariations = await intelligence.generateVariations(insights);
      setVariations(newVariations);

      // Get market updates
      const updates = await intelligence.monitorMarketUpdates();
      setMarketData(updates);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Market Intelligence</h1>
        <Button 
          onClick={generateVariations}
          disabled={isGenerating}
        >
          {isGenerating ? 'Generating...' : 'Generate Variations'}
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Page Variations</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={activeVariation} onValueChange={setActiveVariation}>
              <TabsList>
                {variations.map((v, i) => (
                  <TabsTrigger key={i} value={v.id}>
                    Variation {i + 1}
                  </TabsTrigger>
                ))}
              </TabsList>
              
              {variations.map((variation, i) => (
                <TabsContent key={i} value={variation.id}>
                  <div className="space-y-4">
                    <div className="aspect-video relative">
                      <img 
                        src={variation.preview} 
                        alt={`Variation ${i + 1}`}
                        className="rounded-lg border"
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h3 className="font-medium mb-2">Key Elements</h3>
                        <ul className="space-y-1 text-sm">
                          {variation.elements.map((el, j) => (
                            <li key={j} className="flex items-center gap-2">
                              <span className="w-20 text-muted-foreground">
                                {el.type}:
                              </span>
                              <span>{el.content}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div>
                        <h3 className="font-medium mb-2">Optimization Focus</h3>
                        <ul className="space-y-1 text-sm">
                          {variation.optimizations.map((opt, j) => (
                            <li key={j} className="flex items-center gap-2">
                              <span className="w-24 text-muted-foreground">
                                {opt.type}:
                              </span>
                              <span>{opt.value}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="flex justify-end gap-2">
                      <Button variant="outline">Edit</Button>
                      <Button>Deploy</Button>
                    </div>
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Market Updates</CardTitle>
            </CardHeader>
            <CardContent>
              {marketData && (
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Recent News</h3>
                    <ul className="space-y-2">
                      {marketData.recentNews.map((news, i) => (
                        <li key={i} className="text-sm">
                          <a 
                            href={news.url}
                            className="text-primary hover:underline"
                          >
                            {news.title}
                          </a>
                          <div className="text-xs text-muted-foreground">
                            {news.date} • Sentiment: {news.sentiment}
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-medium mb-2">Scientific Updates</h3>
                    <ul className="space-y-2">
                      {marketData.scientificUpdates.map((study, i) => (
                        <li key={i} className="text-sm">
                          <div>{study.study}</div>
                          <div className="text-xs text-muted-foreground">
                            Impact: {study.impact} • {study.date}
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-medium mb-2">Legal Developments</h3>
                    <ul className="space-y-2">
                      {marketData.legalDevelopments.map((update, i) => (
                        <li key={i} className="text-sm">
                          <div>{update.update}</div>
                          <div className="text-xs text-muted-foreground">
                            {update.jurisdiction} • {update.date}
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
```
