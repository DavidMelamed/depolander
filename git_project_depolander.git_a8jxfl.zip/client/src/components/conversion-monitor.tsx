import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { conversionTracker } from "@/lib/services/analytics";
import { LineChart, Line, XAxis, YAxis, Tooltip } from 'recharts';

export function ConversionMonitor() {
  const [stats, setStats] = useState({
    rate: 0,
    byState: {} as Record<string, number>,
    bySource: {} as Record<string, number>
  });

  useEffect(() => {
    // Update stats every minute
    const interval = setInterval(() => {
      setStats({
        rate: conversionTracker.getConversionRate(),
        byState: {}, // Implement state breakdown
        bySource: {} // Implement source breakdown
      });
    }, 60000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card>
        <CardHeader>
          <CardTitle>Conversion Rate</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">{stats.rate.toFixed(1)}%</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Performance by State</CardTitle>
        </CardHeader>
        <CardContent>
          <LineChart width={400} height={200} data={Object.entries(stats.byState).map(([state, rate]) => ({
            state,
            rate
          }))}>
            <XAxis dataKey="state" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="rate" stroke="#8884d8" />
          </LineChart>
        </CardContent>
      </Card>
    </div>
  );
}
