import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { validateStateContent } from "@/lib/services/batch-generator";

export default function QualityDashboard({ stateContent }: { stateContent: any }) {
  const { valid, issues } = validateStateContent(stateContent);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Content Quality Check</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className={`text-sm ${valid ? 'text-green-600' : 'text-red-600'}`}>
            Status: {valid ? 'Passed' : 'Needs Review'}
          </div>

          {issues.length > 0 && (
            <div className="space-y-2">
              <h4 className="font-medium">Issues Found:</h4>
              <ul className="list-disc pl-4 space-y-1">
                {issues.map((issue, index) => (
                  <li key={index} className="text-sm text-red-600">{issue}</li>
                ))}
              </ul>
            </div>
          )}

          <div className="mt-4">
            <h4 className="font-medium mb-2">Content Stats:</h4>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>Word Count: {countWords(stateContent)}</div>
              <div>Local References: {countLocalReferences(stateContent)}</div>
              <div>CTAs: {countCTAs(stateContent)}</div>
              <div>Keywords: {countKeywords(stateContent)}</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function countWords(content: any): number {
  const text = JSON.stringify(content);
  return text.split(/\s+/).length;
}

function countLocalReferences(content: any): number {
  const text = JSON.stringify(content);
  return (text.match(/(local|near|serving|area|region)/gi) || []).length;
}

function countCTAs(content: any): number {
  const text = JSON.stringify(content);
  return (text.match(/(call|contact|check|evaluate|qualify)/gi) || []).length;
}

function countKeywords(content: any): number {
  const text = JSON.stringify(content);
  return (text.match(/(lawsuit|compensation|settlement|legal|attorney)/gi) || []).length;
}
