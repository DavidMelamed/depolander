import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { generateLocalizedContent } from "@/lib/services/smart-localize";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function StatePreview() {
  const [previews, setPreviews] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState<Record<string, boolean>>({});
  const [selectedStates, setSelectedStates] = useState(['CA', 'TX', 'FL']);

  const generatePreview = async (state: string) => {
    setLoading(prev => ({ ...prev, [state]: true }));
    try {
      const result = await generateLocalizedContent(state);
      setPreviews(prev => ({ ...prev, [state]: result }));
    } finally {
      setLoading(prev => ({ ...prev, [state]: false }));
    }
  };

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
      {selectedStates.map(state => (
        <Card key={state}>
          <CardContent className="p-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold">{state} Preview</h3>
              <Button 
                onClick={() => generatePreview(state)}
                disabled={loading[state]}
              >
                {loading[state] ? 'Generating...' : 'Generate'}
              </Button>
            </div>

            {previews[state] && (
              <Tabs defaultValue="content">
                <TabsList className="w-full">
                  <TabsTrigger value="content">Content</TabsTrigger>
                  <TabsTrigger value="quality">Quality</TabsTrigger>
                </TabsList>

                <TabsContent value="content" className="space-y-4">
                  <div className="preview-section">
                    <h4 className="font-medium text-sm text-muted-foreground">Hero</h4>
                    <p className="mt-1">{previews[state].content.heroTitle}</p>
                    <p className="text-sm mt-1">{previews[state].content.heroDescription}</p>
                  </div>

                  <div className="preview-section">
                    <h4 className="font-medium text-sm text-muted-foreground">Benefits</h4>
                    <ul className="mt-1 space-y-1">
                      {previews[state].content.benefits.map((benefit: string, i: number) => (
                        <li key={i} className="text-sm">{benefit}</li>
                      ))}
                    </ul>
                  </div>
                </TabsContent>

                <TabsContent value="quality">
                  <div className="quality-checks space-y-2">
                    {previews[state].quality.map((check: any) => (
                      <div 
                        key={check.name}
                        className={`flex items-center gap-2 text-sm ${
                          check.passed ? 'text-green-600' : 'text-red-600'
                        }`}
                      >
                        <span>{check.passed ? '✓' : '✗'}</span>
                        <span>{check.name}</span>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
