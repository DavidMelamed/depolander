```typescript
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CopyIcon, CheckIcon } from 'lucide-react';

interface TrackingConfig {
  gtm: {
    containerId: string;
    script: string;
  };
  ringba: {
    accountId: string;
    numbers: string[];
    script: string;
  };
  dataLayer: Record<string, any>;
}

export function TrackingSetup() {
  const [config, setConfig] = useState<TrackingConfig | null>(null);
  const [activeTab, setActiveTab] = useState('gtm');
  const [copied, setCopied] = useState<Record<string, boolean>>({});

  const setupTracking = async () => {
    // Implementation of tracking setup
  };

  const copyToClipboard = async (text: string, key: string) => {
    await navigator.clipboard.writeText(text);
    setCopied({ ...copied, [key]: true });
    setTimeout(() => {
      setCopied({ ...copied, [key]: false });
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Tracking Setup</h2>
        <Button onClick={setupTracking}>Configure Tracking</Button>
      </div>

      {config && (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="gtm">Google Tag Manager</TabsTrigger>
            <TabsTrigger value="ringba">Ringba</TabsTrigger>
            <TabsTrigger value="datalayer">Data Layer</TabsTrigger>
          </TabsList>

          <TabsContent value="gtm">
            <Card>
              <CardHeader>
                <CardTitle>GTM Configuration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label>Container ID</Label>
                    <div className="flex gap-2">
                      <Input value={config.gtm.containerId} readOnly />
                      <Button
                        size="icon"
                        variant="outline"
                        onClick={() => copyToClipboard(config.gtm.containerId, 'gtm-id')}
                      >
                        {copied['gtm-id'] ? (
                          <CheckIcon className="h-4 w-4" />
                        ) : (
                          <CopyIcon className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <div>
                    <Label>Installation Script</Label>
                    <div className="relative">
                      <pre className="p-4 bg-muted rounded-lg text-sm overflow-auto">
                        {config.gtm.script}
                      </pre>
                      <Button
                        size="sm"
                        variant="outline"
                        className="absolute top-2 right-2"
                        onClick={() => copyToClipboard(config.gtm.script, 'gtm-script')}
                      >
                        {copied['gtm-script'] ? 'Copied!' : 'Copy'}
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ringba">
            <Card>
              <CardHeader>
                <CardTitle>Ringba Configuration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label>Account ID</Label>
                    <div className="flex gap-2">
                      <Input value={config.ringba.accountId} readOnly />
                      <Button
                        size="icon"
                        variant="outline"
                        onClick={() => copyToClipboard(config.ringba.accountId, 'ringba-id')}
                      >
                        {copied['ringba-id'] ? (
                          <CheckIcon className="h-4 w-4" />
                        ) : (
                          <CopyIcon className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <div>
                    <Label>Phone Numbers</Label>
                    <div className="space-y-2">
                      {config.ringba.numbers.map((number, index) => (
                        <div key={index} className="flex gap-2">
                          <Input value={number} readOnly />
                          <Button
                            size="icon"
                            variant="outline"
                            onClick={() => copyToClipboard(number, `ringba-number-${index}`)}
                          >
                            {copied[`ringba-number-${index}`] ? (
                              <CheckIcon className="h-4 w-4" />
                            ) : (
                              <CopyIcon className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label>Installation Script</Label>
                    <div className="relative">
                      <pre className="p-4 bg-muted rounded-lg text-sm overflow-auto">
                        {config.ringba.script}
                      </pre>
                      <Button
                        size="sm"
                        variant="outline"
                        className="absolute top-2 right-2"
                        onClick={() => copyToClipboard(config.ringba.script, 'ringba-script')}
                      >
                        {copied['ringba-script'] ? 'Copied!' : 'Copy'}
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="datalayer">
            <Card>
              <CardHeader>
                <CardTitle>Data Layer Configuration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="relative">
                    <pre className="p-4 bg-muted rounded-lg text-sm overflow-auto">
                      {JSON.stringify(config.dataLayer, null, 2)}
                    </pre>
                    <Button
                      size="sm"
                      variant="outline"
                      className="absolute top-2 right-2"
                      onClick={() => copyToClipboard(JSON.stringify(config.dataLayer), 'datalayer')}
                    >
                      {copied['datalayer'] ? 'Copied!' : 'Copy'}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
```
