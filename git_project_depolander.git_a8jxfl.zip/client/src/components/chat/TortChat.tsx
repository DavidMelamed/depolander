```typescript
import { useState, useEffect, useRef } from 'react';
import { TortChatSystem } from '@/lib/services/chat-system';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, Send, ChevronRight } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: number;
  nextSteps?: string[];
  cta?: {
    text: string;
    action: string;
  };
}

export function TortChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatRef = useRef<HTMLDivElement>(null);
  const chatSystem = useRef<TortChatSystem>();

  useEffect(() => {
    // Initialize chat system with context
    chatSystem.current = new TortChatSystem({
      tort: 'Depo-Provera',
      userLocation: 'California', // This should be dynamic based on user
    });

    // Add initial welcome message
    setMessages([{
      id: '0',
      type: 'assistant',
      content: 'Hello! I can help you understand your legal options regarding Depo-Provera. What questions do you have?',
      timestamp: Date.now(),
      nextSteps: [
        'Check your eligibility',
        'Learn about compensation',
        'Understand the process'
      ]
    }]);
  }, []);

  const sendMessage = async (content: string) => {
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content,
      timestamp: Date.now()
    };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      // Get response from chat system
      const response = await chatSystem.current?.processMessage(content);
      
      // Add assistant message
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: response.response,
        timestamp: Date.now(),
        nextSteps: response.nextSteps?.steps,
        cta: response.cta
      };
      setMessages(prev => [...prev, assistantMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto h-[600px] flex flex-col">
      <div className="p-4 border-b bg-primary text-primary-foreground">
        <h3 className="font-semibold">Legal Assistant</h3>
        <p className="text-sm opacity-90">Get answers about your Depo-Provera case</p>
      </div>

      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${
                message.type === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.type === 'user'
                    ? 'bg-primary text-primary-foreground ml-4'
                    : 'bg-muted mr-4'
                }`}
              >
                <p className="text-sm">{message.content}</p>
                
                {message.nextSteps && (
                  <div className="mt-3 space-y-2">
                    {message.nextSteps.map((step, index) => (
                      <Button
                        key={index}
                        variant="ghost"
                        className="w-full justify-start text-sm"
                        onClick={() => sendMessage(step)}
                      >
                        <ChevronRight className="mr-2 h-4 w-4" />
                        {step}
                      </Button>
                    ))}
                  </div>
                )}

                {message.cta && (
                  <Button
                    className="w-full mt-3"
                    onClick={() => {
                      // Handle CTA action
                      console.log('CTA clicked:', message.cta.action);
                    }}
                  >
                    {message.cta.text}
                  </Button>
                )}
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-muted rounded-lg p-3 mr-4">
                <Loader2 className="h-4 w-4 animate-spin" />
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      <div className="p-4 border-t">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (input.trim()) {
              sendMessage(input.trim());
            }
          }}
          className="flex gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 rounded-md border px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <Button type="submit" size="icon" disabled={!input.trim() || isTyping}>
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </Card>
  );
}
```
