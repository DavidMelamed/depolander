```typescript
import { useState } from 'react';
import { MarketingAgent } from '@/lib/services/marketing-agent';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface AdCreative {
  id: string;
  headlines: string[];
  descriptions: string[];
  displayUrl: string;
  finalUrl: string;
  keywords: string[];
  targeting: Record<string, any>;
}

export function AdCreativeGenerator() {
  const [creatives, setCreatives] = useState<AdCreative[]>([]);
  const [selectedCreative, setSelectedCreative] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const generateCreatives = async () => {
    setIsGenerating(true);
    try {
      const agent = new MarketingAgent();
      const result = await agent.executeTask({
        type: 'ad_creation',
        parameters: {
          landingPage: {
            // Get current page content
            content: document.body.innerHTML,
            url: window.location.href
          },
          targeting: {
            location: 'California', // This should be dynamic
            interests: ['legal services', 'medical information'],
            demographics: {
              age: ['25-65'],
              gender: ['female']
            }
          }
        }
      });

      setCreatives(result.creatives);
      if (result.creatives.length > 0) {
        setSelectedCreative(result.creatives[0].id);
      }
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Ad Creatives</h2>
        <Button 
          onClick={generateCreatives}
          disabled={isGenerating}
        >
          {isGenerating ? 'Generating...' : 'Generate Ads'}
        </Button>
      </div>

      {creatives.length > 0 && (
        <Tabs value={selectedCreative} onValueChange={setSelectedCreative}>
          <TabsList>
            {creatives.map((creative) => (
              <TabsTrigger key={creative.id} value={creative.id}>
                Variation {creative.id}
              </TabsTrigger>
            ))}
          </TabsList>

          {creatives.map((creative) => (
            <TabsContent key={creative.id} value={creative.id}>
              <Card>
                <CardHeader>
                  <CardTitle>Ad Preview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="font-medium mb-2">Headlines</h3>
                      <div className="space-y-2">
                        {creative.headlines.map((headline, index) => (
                          <div
                            key={index}
                            className="p-2 bg-muted rounded text-sm"
                          >
                            {headline}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="font-medium mb-2">Descriptions</h3>
                      <div className="space-y-2">
                        {creative.descriptions.map((desc, index) => (
                          <div
                            key={index}
                            className="p-2 bg-muted rounded text-sm"
                          >
                            {desc}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h3 className="font-medium mb-2">URLs</h3>
                        <div className="space-y-1 text-sm">
                          <div>Display: {creative.displayUrl}</div>
                          <div>Final: {creative.finalUrl}</div>
                        </div>
                      </div>

                      <div>
                        <h3 className="font-medium mb-2">Keywords</h3>
                        <div className="flex flex-wrap gap-1">
                          {creative.keywords.map((keyword, index) => (
                            <span
                              key={index}
                              className="px-2 py-1 bg-primary/10 rounded-full text-xs"
                            >
                              {keyword}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-medium mb-2">Targeting</h3>
                      <pre className="p-2 bg-muted rounded text-xs overflow-auto">
                        {JSON.stringify(creative.targeting, null, 2)}
                      </pre>
                    </div>

                    <div className="flex justify-end gap-2">
                      <Button variant="outline">Edit</Button>
                      <Button>Deploy</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      )}
    </div>
  );
}
```
