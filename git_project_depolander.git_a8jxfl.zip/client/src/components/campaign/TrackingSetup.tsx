```typescript
import { MarketingAgent } from './marketing-agent';
import { TortChatSystem } from './chat-system';

interface CampaignConfig {
  tort: string;
  locations: string[];
  budget: number;
  startDate: Date;
  endDate: Date;
  targeting: Record<string, any>;
}

export class CampaignManager {
  private agent: MarketingAgent;
  private chatSystems: Map<string, TortChatSystem>;

  async createCampaign(config: CampaignConfig) {
    // Generate landing pages for each location
    const pages = await this.generateLocationPages(config);

    // Create message-matched ads
    const ads = await this.createAds(pages, config);

    // Setup tracking
    const tracking = await this.setupTracking(pages);

    // Initialize chat systems
    await this.initializeChatSystems(config);

    return {
      pages,
      ads,
      tracking,
      urls: this.generateTrackingUrls(pages, config)
    };
  }

  private async generateLocationPages(config: CampaignConfig) {
    const pages = {};
    
    for (const location of config.locations) {
      pages[location] = await this.agent.executeTask({
        type: 'landing_page',
        parameters: {
          tort: config.tort,
          location,
          targeting: config.targeting
        }
      });
    }

    return pages;
  }

  private async createAds(pages: Record<string, any>, config: CampaignConfig) {
    const ads = {};

    for (const [location, page] of Object.entries(pages)) {
      ads[location] = await this.agent.executeTask({
        type: 'ad_creation',
        parameters: {
          landingPage: page,
          targeting: {
            ...config.targeting,
            location
          }
        }
      });
    }

    return ads;
  }

  private async setupTracking(pages: Record<string, any>) {
    const domains = Object.values(pages).map(page => page.domain);
    const phoneNumbers = Object.values(pages).map(page => page.phoneNumber);

    return this.agent.executeTask({
      type: 'tracking_setup',
      parameters: {
        domains,
        phoneNumbers
      }
    });
  }

  private async initializeChatSystems(config: CampaignConfig) {
    this.chatSystems = new Map();

    for (const location of config.locations) {
      this.chatSystems.set(location, new TortChatSystem({
        tort: config.tort,
        userLocation: location
      }));
    }
  }

  private generateTrackingUrls(pages: Record<string, any>, config: CampaignConfig) {
    return this.agent.executeTask({
      type: 'utm_builder',
      parameters: {
        pages,
        campaign: config.tort.toLowerCase().replace(/\s+/g, '-'),
        source: 'google',
        medium: 'cpc'
      }
    });
  }
}
```
