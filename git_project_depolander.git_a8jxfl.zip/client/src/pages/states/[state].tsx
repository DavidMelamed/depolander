import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { generateLocalizedCopy } from "@/lib/services/smart-localize";
import HeroSection from "@/components/hero-section";
import BenefitsSection from "@/components/benefits-section";
import LocalCTA from "@/components/local-cta";
import { siteConfig } from "@/lib/config";

export default function StatePage() {
  const { state } = useParams();
  const { data: localContent, isLoading } = useQuery(
    ['state-content', state],
    () => generateLocalizedCopy(state)
  );

  if (isLoading) {
    return <div>Generating localized content...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <HeroSection 
        title={localContent.content.hero.title}
        description={localContent.content.hero.description}
        phone={siteConfig.contact.phone}
      />
      
      <BenefitsSection 
        items={localContent.content.benefits}
        disclaimer={localContent.content.disclaimer}
      />

      <LocalCTA 
        state={state}
        cities={localContent.content.cities}
      />
    </div>
  );
}
