import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import StatePreview from "@/components/state-preview";
import { generateBatch } from "@/lib/services/batch-generator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function StateGenerator() {
  const [states, setStates] = useState<string>("");
  const [generating, setGenerating] = useState(false);
  const [results, setResults] = useState<any[]>([]);

  const handleBatchGenerate = async () => {
    setGenerating(true);
    try {
      const stateList = states.split(",").map(s => s.trim().toUpperCase());
      const batchResults = await generateBatch(stateList);
      setResults(batchResults);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>State Page Generator</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6">
            <Input
              placeholder="Enter state codes (e.g., CA, TX, FL)"
              value={states}
              onChange={(e) => setStates(e.target.value)}
            />
            <Button 
              onClick={handleBatchGenerate}
              disabled={generating || !states}
            >
              {generating ? 'Generating...' : 'Generate Batch'}
            </Button>
          </div>

          {results.length > 0 && (
            <div className="space-y-2">
              {results.map((result, index) => (
                <div 
                  key={index}
                  className={`p-2 rounded ${
                    result.passed ? 'bg-green-100' : 'bg-red-100'
                  }`}
                >
                  <span className="font-medium">{result.state}:</span>
                  {result.passed ? ' Generated successfully' : ' Failed quality checks'}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <StatePreview />
    </div>
  );
}
