import { Configuration, OpenAIApi } from 'openai';
import { siteConfig } from '../../client/src/lib/config';
import type { StateContent, StateContentResult } from '../../client/src/lib/types/state-content';

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});

const openai = new OpenAIApi(configuration);

export async function generateLocalizedContent({ 
  prompt, 
  state 
}: { 
  prompt: string; 
  state: string;
}): Promise<StateContentResult> {
  try {
    const completion = await openai.createChatCompletion({
      model: "gpt-4",
      messages: [{
        role: "system",
        content: "You are a legal marketing expert specializing in mass tort campaigns."
      }, {
        role: "user",
        content: prompt
      }],
      temperature: 0.7,
    });

    const content = JSON.parse(completion.data.choices[0].message?.content || '{}');
    
    return {
      content,
      quality: runQualityChecks(content),
      passed: true,
      meta: {
        generatedAt: new Date().toISOString(),
        aiModel: "gpt-4"
      }
    };
  } catch (error) {
    console.error('AI generation error:', error);
    throw new Error('Failed to generate content');
  }
}

function runQualityChecks(content: StateContent) {
  // Implementation of quality checks
  return [];
}
