import { Router } from 'express';
import { generateLocalizedContent } from '../services/ai-content';

const router = Router();

router.post('/generate', async (req, res) => {
  try {
    const { prompt, state } = req.body;
    const content = await generateLocalizedContent({ prompt, state });
    res.json(content);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/batch', async (req, res) => {
  try {
    const { states } = req.body;
    const results = await Promise.all(
      states.map(state => generateLocalizedContent({ state }))
    );
    res.json(results);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
